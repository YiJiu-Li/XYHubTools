// Unity 2022.3 shim: UnityEditor.ConsoleWindowUtility only became public in Unity 6.
// This provides the two members EditorConsoleGroundTruth uses, backed by the public
// Application.logMessageReceived callback so the console counts still work.
#if !UNITY_6000_0_OR_NEWER
using System;
using UnityEngine;

namespace UnityEditor
{
    internal static class ConsoleWindowUtility
    {
        static int s_Errors;
        static int s_Warnings;
        static int s_Logs;

        public static event Action consoleLogsChanged;

        static ConsoleWindowUtility()
        {
            Application.logMessageReceived += OnLogMessageReceived;
        }

        static void OnLogMessageReceived(string message, string stackTrace, LogType type)
        {
            switch (type)
            {
                case LogType.Error:
                case LogType.Assert:
                case LogType.Exception:
                    s_Errors++;
                    break;
                case LogType.Warning:
                    s_Warnings++;
                    break;
                default:
                    s_Logs++;
                    break;
            }

            consoleLogsChanged?.Invoke();
        }

        public static void GetConsoleLogCounts(out int errorCount, out int warningCount, out int logCount)
        {
            errorCount = s_Errors;
            warningCount = s_Warnings;
            logCount = s_Logs;
        }
    }
}
#endif
